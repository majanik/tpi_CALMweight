#include <iostream>
#include "CorrFctnDirectYlm.h"
#include <TH1D.h>
#include <TRandom2.h>
#include <math.h>
#include <TFile.h>
#include <complex>

using namespace std;

int main(int argc, char **argv)
{
  TFile *ofile = new TFile("shmout.recalc.root","RECREATE");

  CorrFctnDirectYlm *cylm = new CorrFctnDirectYlm(argv[2],3,40,0.0,0.2);
  TFile *infile = new TFile(argv[1]);
#ifdef _SH_EXP_
  if (argc>2) {
    Double_t radius = atof(argv[3])/0.197327;
    Double_t bohrac = atof(argv[4])/0.197327;
    
    cylm->SetAdvancedNormalization(radius/0.197327, bohrac/0.197327, 0.72, 21,40);
  }
#endif
  cylm->ReadFromFile(infile, argv[2], 3);

  ofile->cd();
  cylm->Write();

  delete cylm;
}

  
